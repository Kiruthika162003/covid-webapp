export default [
  {
    message:
      'Please do not hoard supplies, authorities will make sure everyone gets essentials.',
  },
  {
    message:
      'Be a responsible citizen, do not forward any Whatsapp message unless you have verified the source',
  },
  {
    message:
      'Show compassion. Be considerate. Help others. We will get through this. TOGETHER!',
  },
];
